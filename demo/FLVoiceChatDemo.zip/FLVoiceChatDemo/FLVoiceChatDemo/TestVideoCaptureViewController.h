//
//  TestVideoCaptureViewController.h
//  FLVoiceChatDemo
//
//  Created by Fan Lv on 2018/3/7.
//  Copyright © 2018年 Fanlv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestVideoCaptureViewController : UIViewController

@end
