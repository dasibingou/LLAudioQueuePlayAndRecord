//
//  FLNavigationController.m
//  FLVoiceChatDemo
//
//  Created by Fan Lv on 2018/3/7.
//  Copyright © 2018年 Fanlv. All rights reserved.
//

#import "FLNavigationController.h"

@interface FLNavigationController ()

@end

@implementation FLNavigationController

//- (BOOL)shouldAutorotate {
//    return YES;
//}
//
//- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
//    return UIInterfaceOrientationMaskLandscape;
//}
//
//- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation {
//    UIInterfaceOrientation orientation = [super preferredInterfaceOrientationForPresentation];
//    if ((orientation != UIInterfaceOrientationLandscapeLeft) && (orientation != UIInterfaceOrientationLandscapeRight)) {
//        orientation = UIInterfaceOrientationLandscapeRight;
//    }
//    return orientation;
//}
@end
