//
//  AppDelegate.h
//  FLVoiceChatDemo
//
//  Created by Fan Lv on 16/8/26.
//  Copyright © 2016年 Fanlv. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

